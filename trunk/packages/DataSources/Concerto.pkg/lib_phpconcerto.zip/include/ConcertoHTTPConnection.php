<?php
    require_once("iConcertoConnection.php");
    
    // the class that performs a connection to concerto over http
    class ConcertoHTTPConnection implements iConcertoConnection {
        private $_server;
        private $_port;
        private $_suffix;
        
        function __construct($args) {
            $this->_server = $args['server'];
            $this->_port = $args['port'];
            $this->_suffix = $args['suffix'];
        }
        private function get_connection_string($params,$args = true) {
            $get = array();
            $paramstr = null;
            if ($params) {
                foreach ($params as $key=>$val) {
                    $str = "$key=$val";
                    $get[] = $str;
                }
                $paramstr = implode("&",$get);
            }
        
            $str = $this->_server;
            if ($this->_port != 80)
                $str .= ":" . $this->_port;
                
            $str .= $this->_suffix;
            $str .= ($args ? "/?" . $paramstr : '');
            return $str;
        }
        function Verify() {
            if (fopen($this->get_connection_string(false),'r')) return true;
            else return false;
        }
        function Query($params) {
            $query = $this->get_connection_string($params);
            $fd = fopen($query, 'r');
            while ($line = fread($fd,4096)) 
                $xmlbuf .= $line;
            fclose($fd);
            
            return $xmlbuf;
        }
    }
?>
<?php
    interface iConcertoConnection {
        function Verify();
        function Query($params);
    }

?>